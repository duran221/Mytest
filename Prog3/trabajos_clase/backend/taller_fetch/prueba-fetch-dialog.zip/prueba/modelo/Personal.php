<?php

class Personal {

    /**
     * Devuelve una cadena JSON que contiene el resultado de seleccionar personal
     * Se usa PDO. Ver https://diego.com.es/tutorial-de-pdo
     */
    public function seleccionar($param) {
        $perfil = '';
        extract($param);

        $sql = "SELECT id_persona, nombre, telefono, direccion,perfil,contrasena
                    FROM personal
                WHERE perfil LIKE '%$perfil'
                ORDER BY nombre";
        // prepara la instrucción SQL para ejecutarla, luego recibir los parámetros de filtrado
        $instruccion = $conexion->pdo->prepare($sql);
        $instruccion->execute();
        $filas = $instruccion->fetchAll(PDO::FETCH_ASSOC); // devuelve un array que contiene todas las filas del conjunto de resultados
        echo json_encode($filas); // las filas resultantes son enviadas en formato JSON al frontend
    }

}