/**
 * Ejemplo de uso de MaterialDialog
 * Consulte las diferencias entre la versión original:
 * (https://github.com/rudmanmrrod/material-dialog/blob/master/src/material-dialog.js)
 * y la versión escrita por Carlos Cuesta I.
 * Ambas versiones son totalmente compatibles
 */
'use strict';

import { MaterialDialog } from '../libs/material-dialog.js';

((doc, win) => {

    // este script se insertará más adelante en un cuadro de diálogo
    let html = `<!-- especificaciones de un cuadro modal -->
                <br>
                Esta es una demostración de cómo usar el componente MaterialDialog y la API fetch de Javascript
                para hacer peticiones asíncronas. Para que esto funcione, correctamente debe:
                <br><br>
                - Actualizar conexion.json con los datos de la base de datos con la que se viene trabajando.
                <br>
                - Ingresar como perfil del usuario, el dato "Administrador" o el dato "Vendedor"
                <br><br>
                Asegúrese de entender plenamente el funcionamiento de esta demostración...servirá de base para un taller
                calificable en la próxima clase.
                <br><br>
                <form class="col s12">
                    <div class="row">
                        <div class="input-field col s12">
                            <input class="validate" type="text" name="txtperfil" id="txtperfil" required/>
                            <label for="txtperfil">Perfil del usuario: [Administrador | Vendedor]</label>
                        </div>
                    </div>
                </form>
                <!-- hasta aquí el formulario de autenticación -->`;

    // un ejemplo de cómo utizar la función fetchData para recuperar datos del back-end
    let buscarDatos = () => {
        // el dato que ingresa al usuario y que será buscado en la base de datos
        let perfil = document.querySelector('#txtperfil').value;
        console.log(perfil);

        // envío de una solicitud al back-end para que proporcione algunos datos
        fetchData('./controlador/fachada.php', {
            'method': 'POST',
            'body': {
                clase: 'Personal',
                accion: 'seleccionar',
                perfil: perfil
            }
        }).then(data => {
            // respuesta del back-end y tratamiento de los datos recibidos
            mostrarDatos(data);
        });
    }

    // Una simple visualización de los datos recibidos en la línea 40
    let mostrarDatos = (data) => {
        console.log(data);

        if (data.length > 0) {
            let html = 'Resultado de la búsqueda:<br>';
            data.forEach((item) => {
                html += `${item.id_persona} - ${item.nombre}<br>`;
            });
            document.querySelector('#index-contenedor').innerHTML = html;
        } else {
            MaterialDialog.alert('No hay registros para mostrar', { title: 'Resultado' });
        }
    }

    doc.addEventListener('DOMContentLoaded', event => {
        // cuando el DOM está cargado se crea un diálogo con el html de la línea 14
        MaterialDialog.dialog(html, {
            title: 'Filtrar datos',
            buttons: {
                close: {
                    text: 'Terminar'
                },
                confirm: {
                    text: 'Filtrar',
                    callback: buscarDatos // uso de la función definida en la línea 27
                }
            }
        });
    });

    /**
     * permite obtener una promesa con recursos de forma asíncrona por el canal HTTP
     * @param {String} url La dirección a la que se envía la petición.
     * @param {Object} data Opcional. Un objeto para enviar argumentos.
     */
    let fetchData = async(url, data = {}) => {
        if (!('method' in data)) {
            data.method = 'POST';
        }

        if (!('headers' in data)) {
            data.headers = {
                'Content-Type': 'application/json'
            };
        }

        if ('body' in data) {
            data.body = JSON.stringify(data.body);
        }

        const respuesta = await fetch(url, data); // uso de la función fetch de ES6

        if (!respuesta.ok) {
            console.log(`Error al cargar ${url}: ${respuesta.status} - ${respuesta.statusText}`);
        }

        return await respuesta.json();
    }

})(document, window);